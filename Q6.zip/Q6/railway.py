"""Q6 - Nested data: A Railway Timetable (enquiry counter).

NOTE: the 5 trains below are SAMPLE data for the exercise, not the official timetable.
"""
import json
import os
import random
import time
import tracemalloc

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}
DAYS = ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")


def best_time(fn, repeat=3):
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


# timetable[train_no] = {"name": str, "stops": [(station, arrival, departure), ...], "days": {..}}
timetable = {
    12001: {"name": "Chennai - Madurai Express",
            "stops": [("Chennai Central", "--", "06:00"), ("Villupuram", "08:10", "08:12"),
                      ("Tiruchirappalli", "10:30", "10:35"), ("Dindigul", "11:40", "11:42"),
                      ("Madurai", "13:00", "--")],
            "days": {"Mon", "Wed", "Fri", "Sun"}},
    12002: {"name": "Chennai - Coimbatore Intercity",
            "stops": [("Chennai Central", "--", "06:15"), ("Katpadi", "08:00", "08:02"),
                      ("Salem", "10:20", "10:25"), ("Erode", "11:15", "11:17"),
                      ("Coimbatore", "12:45", "--")],
            "days": set(DAYS)},
    12003: {"name": "Chennai - Bengaluru Shatabdi",
            "stops": [("Chennai Central", "--", "06:00"), ("Katpadi", "07:30", "07:32"),
                      ("Bengaluru", "11:00", "--")],
            "days": {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}},
    12004: {"name": "Madurai - Chennai Night Express",
            "stops": [("Madurai", "--", "21:00"), ("Dindigul", "22:05", "22:07"),
                      ("Tiruchirappalli", "23:15", "23:20"), ("Villupuram", "01:40", "01:42"),
                      ("Chennai Central", "04:30", "--")],
            "days": {"Tue", "Thu", "Sat"}},
    12005: {"name": "Coimbatore - Chennai Express",
            "stops": [("Coimbatore", "--", "22:00"), ("Erode", "23:05", "23:07"),
                      ("Salem", "00:00", "00:05"), ("Katpadi", "02:30", "02:32"),
                      ("Chennai Central", "05:00", "--")],
            "days": {"Mon", "Fri", "Sun"}},
}


def print_timetable(tt):
    for no in sorted(tt):
        t = tt[no]
        print(f"\nTrain {no}  {t['name']}  runs: {', '.join(d for d in DAYS if d in t['days'])}")
        print(f"  {'Station':<18}{'Arr':>7}{'Dep':>7}")
        for st, arr, dep in t["stops"]:
            print(f"  {st:<18}{arr:>7}{dep:>7}")


def trains_at_scan(tt, station, day):
    """No index: look at every stop of every train."""
    found = []
    for no, t in tt.items():
        if day not in t["days"]:
            continue
        for st, arr, dep in t["stops"]:
            if st == station:
                found.append((no, t["name"], arr, dep))
                break
    return sorted(found, key=lambda r: (r[3] == "--", r[3]))     # by departure; terminating trains last


def build_index(tt):
    """station -> list of train numbers that stop there."""
    idx = {}
    for no, t in tt.items():
        for st, _, _ in t["stops"]:
            idx.setdefault(st, []).append(no)
    return idx


def trains_at_indexed(tt, idx, station, day):
    found = []
    for no in idx.get(station, []):                              # only trains that stop here
        t = tt[no]
        if day in t["days"]:
            for st, arr, dep in t["stops"]:
                if st == station:
                    found.append((no, t["name"], arr, dep))
                    break
    return sorted(found, key=lambda r: (r[3] == "--", r[3]))


def flat_list(tt):
    """Alternative design: one flat list of (train, station, arrival, departure, days) tuples."""
    return [(no, st, arr, dep, frozenset(t["days"])) for no, t in tt.items() for st, arr, dep in t["stops"]]


def trains_at_flat(flat, station, day):
    found = [(no, "", arr, dep) for no, st, arr, dep, days in flat if st == station and day in days]
    return sorted(found, key=lambda r: (r[3] == "--", r[3]))


def make_timetable(n_trains, n_stations=300, stops_per_train=12, seed=11):
    rnd = random.Random(seed)
    stations = [f"Station{i:03d}" for i in range(n_stations)]
    tt = {}
    for k in range(n_trains):
        route = rnd.sample(stations, stops_per_train)
        minutes = rnd.randrange(0, 600)
        stops = []
        for i, st in enumerate(route):
            arr = "--" if i == 0 else f"{(minutes // 60) % 24:02d}:{minutes % 60:02d}"
            minutes += 2
            dep = "--" if i == stops_per_train - 1 else f"{(minutes // 60) % 24:02d}:{minutes % 60:02d}"
            stops.append((st, arr, dep))
            minutes += rnd.randrange(30, 120)
        tt[10000 + k] = {"name": f"Train {10000 + k}", "stops": stops,
                         "days": set(rnd.sample(DAYS, rnd.randint(1, 7)))}
    return tt


if __name__ == "__main__":
    print_timetable(timetable)

    print("\nReaching nested data:")
    print("  timetable[12001]['name']                =", timetable[12001]["name"])
    print("  timetable[12001]['stops'][2]            =", timetable[12001]["stops"][2])
    print("  timetable[12001]['stops'][2][2]         =", timetable[12001]["stops"][2][2],
          " <- departure time from the THIRD station")
    print("  'Fri' in timetable[12001]['days']       =", "Fri" in timetable[12001]["days"])

    station, day = "Katpadi", "Fri"
    print(f"\nTrains stopping at {station} on {day}, sorted by departure (key=lambda):")
    for r in trains_at_scan(timetable, station, day):
        print(f"  {r[0]}  {r[1]:<34} arr {r[2]:>5}  dep {r[3]:>5}")
    idx = build_index(timetable)
    assert trains_at_scan(timetable, station, day) == trains_at_indexed(timetable, idx, station, day)
    assert [r[0] for r in trains_at_scan(timetable, station, day)] == \
           [r[0] for r in trains_at_flat(flat_list(timetable), station, day)]
    print("Scan, indexed and flat-list answers agree: True")
    print("Index:", {k: v for k, v in idx.items()})

    print("\nEdge cases:")
    print("  unknown station 'Atlantis' ->", trains_at_scan(timetable, "Atlantis", "Fri"),
          "| indexed:", trains_at_indexed(timetable, idx, "Atlantis", "Fri"))
    print("  12003 does not run on Sunday; Katpadi/Sun ->",
          [r[0] for r in trains_at_scan(timetable, "Katpadi", "Sun")], "(12003 absent: correct)")
    print("  invalid day 'Xyz' ->", trains_at_scan(timetable, "Katpadi", "Xyz"))

    print("\nTiming (200 random station queries, 12 stops per train, 300 stations):")
    rows = []
    for n in (100, 1_000, 10_000):
        tt = make_timetable(n)
        flat = flat_list(tt)
        rnd = random.Random(1)
        queries = [(f"Station{rnd.randrange(300):03d}", rnd.choice(DAYS)) for _ in range(200)]
        tracemalloc.start()
        idx = build_index(tt)
        _, peak = tracemalloc.get_traced_memory()
        cur, _ = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        t_scan = best_time(lambda: [trains_at_scan(tt, s, d) for s, d in queries])
        t_idx = best_time(lambda: [trains_at_indexed(tt, idx, s, d) for s, d in queries])
        t_flat = best_time(lambda: [trains_at_flat(flat, s, d) for s, d in queries], 1 if n >= 10_000 else 3)
        t_build = best_time(lambda: build_index(tt))
        for s, d in queries[:50]:
            assert trains_at_scan(tt, s, d) == trains_at_indexed(tt, idx, s, d)
        row = {"trains": n, "stops": n * 12, "scan": t_scan / 200, "indexed": t_idx / 200,
               "flat": t_flat / 200, "build": t_build, "index_bytes": cur}
        rows.append(row)
        print("  trains={trains:>6} stops={stops:>7}: per query scan={scan:.2e}s  flat={flat:.2e}s  "
              "indexed={indexed:.2e}s | index build={build:.4f}s  extra memory={index_bytes:,} bytes".format(**row))
    R["timing"] = rows

    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
