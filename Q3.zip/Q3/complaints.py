"""Q3 - Dictionaries: Farmer Helpline (Kisan Call Centre) complaint analysis."""
import json
import os
import random
import re
import time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}
STOP = {"not", "the", "is", "a", "of", "and", "to", "in", "for", "has", "have", "my", "very"}


def best_time(fn, repeat=3):
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


def words_of(text):
    """Lower-case and keep only letters/digits, so 'Seeds,' == 'seeds'."""
    return re.findall(r"[a-z0-9]+", text.lower())


def freq_get(texts, stop):                      # method 1: dict + get()
    counts = {}
    for t in texts:
        for w in words_of(t):
            if w not in stop:
                counts[w] = counts.get(w, 0) + 1
    return counts


def freq_setdefault(texts, stop):               # method 2: dict + setdefault()
    counts = {}
    for t in texts:
        for w in words_of(t):
            if w not in stop:
                counts[w] = counts.setdefault(w, 0) + 1   # setdefault returns the current value
    return counts


def freq_listcount(texts, stop):                # method 3: list.count() per distinct word
    words = [w for t in texts for w in words_of(t) if w not in stop]
    return {w: words.count(w) for w in set(words)}


def freq_counter(texts, stop):                  # method 4: collections.Counter
    return Counter(w for t in texts for w in words_of(t) if w not in stop)


def top_k(counts, k):
    """Highest count first; ties alphabetical."""
    return sorted(counts.items(), key=lambda p: (-p[1], p[0]))[:k]


def group_by(records, key):
    groups = {}
    for rec in records:
        groups.setdefault(rec[key], []).append(rec["text"])
    return groups


VOCAB = ["seeds", "fertiliser", "price", "subsidy", "pump", "loan", "insurance", "rain", "pest", "tractor"] + \
        [f"word{i}" for i in range(90)] + sorted(STOP)
DISTRICTS = ["Thanjavur", "Madurai", "Salem", "Erode", "Vellore", "Theni"]
CROPS = ["paddy", "cotton", "sugarcane", "banana", "groundnut"]


def make_complaints(n, seed=3):
    rnd = random.Random(seed)
    return [{"district": rnd.choice(DISTRICTS), "crop": rnd.choice(CROPS),
             "text": " ".join(rnd.choice(VOCAB) for _ in range(rnd.randint(5, 10)))} for _ in range(n)]


if __name__ == "__main__":
    sample = [
        {"district": "Thanjavur", "crop": "paddy", "text": "Seeds not received, seeds delayed!"},
        {"district": "Madurai", "crop": "cotton", "text": "Fertiliser PRICE high"},
        {"district": "Thanjavur", "crop": "paddy", "text": "Seeds price high; subsidy not received."},
        {"district": "Salem", "crop": "banana", "text": ""},
    ]
    texts = [r["text"] for r in sample]
    stop = {"not", "high"}
    c1, c2, c3, c4 = (f(texts, stop) for f in (freq_get, freq_setdefault, freq_listcount, freq_counter))
    print("Word frequencies (get)       :", c1)
    assert c1 == c2 == c3 == dict(c4)
    print("All four methods agree       : True")
    print("Top 3 (count desc, then a-z) :", top_k(c1, 3))
    print("Complaints per district      :", {d: len(v) for d, v in group_by(sample, "district").items()})
    print("Complaints grouped by crop   :", group_by(sample, "crop"))

    print("\nEdge cases:")
    print("  empty text            ->", freq_get([""], stop), top_k(freq_get([""], stop), 3))
    print("  no complaints at all  ->", freq_get([], stop))
    print("  'Seeds SEEDS seeds'   ->", freq_get(["Seeds SEEDS seeds"], stop))
    print("  'price, price. price!'->", freq_get(["price, price. price!"], stop))
    print("  only stop words       ->", freq_get(["not high not"], stop))

    d = {"a": 1, "b": 2}
    print("\nViews:", d.keys(), d.values(), d.items())
    view = d.keys()
    d["c"] = 3
    print("A view is live; after adding 'c':", view)

    print("\nTiming, best of 3 (seconds) - vocabulary of 100 distinct words + 13 stop words:")
    rows = []
    for n in (1_000, 10_000, 100_000):
        data = [r["text"] for r in make_complaints(n)]
        row = {"n": n, "words": sum(len(words_of(t)) for t in data)}
        row["dict_get"] = best_time(lambda: freq_get(data, STOP))
        row["setdefault"] = best_time(lambda: freq_setdefault(data, STOP))
        row["counter"] = best_time(lambda: freq_counter(data, STOP))
        row["list_count"] = best_time(lambda: freq_listcount(data, STOP), 1 if n >= 100_000 else 3)
        assert freq_get(data, STOP) == freq_listcount(data, STOP) == dict(freq_counter(data, STOP))
        rows.append(row)
        print("  complaints={n:>7} words={words:>8}  dict.get={dict_get:.4f}  setdefault={setdefault:.4f}  "
              "Counter={counter:.4f}  list.count={list_count:.4f}".format(**row))
    R["timing"] = rows

    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
