"""Q1 - Lists and slicing: Daily Rainfall Records (Village Rain-Gauge Station)."""
import bisect
import json
import math
import os
import random
import time
from collections import deque

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}  # results, saved to results.json for the report


def best_time(fn, repeat=3):
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


def per_call(make_list, op, k=20):
    """Average seconds for one call of op(list), measured over k calls."""
    lst = make_list()
    t0 = time.perf_counter()
    for _ in range(k):
        op(lst)
    return (time.perf_counter() - t0) / k


def make_readings(n, seed=1):
    """n daily readings in mm: about 35% dry days, otherwise 0.1-60.0 mm."""
    rnd = random.Random(seed)
    return [0.0 if rnd.random() < 0.35 else round(rnd.uniform(0.1, 60), 1) for _ in range(n)]


# ---------------------------------------------------------------- tasks
def weekly_totals(r):
    """Total rainfall of each 7-day block (last block may be shorter)."""
    return [round(sum(r[i:i + 7]), 1) for i in range(0, len(r), 7)]


def wettest_driest(r):
    """(week_no, total) of the wettest and driest FULL week; None if no full week."""
    full = weekly_totals(r[:len(r) // 7 * 7])
    if not full:
        return None
    wet, dry = max(full), min(full)
    return (full.index(wet) + 1, wet), (full.index(dry) + 1, dry)


def max_min_with_positions(r):
    if not r:
        return None
    mx, mn = max(r), min(r)
    return (mx, r.index(mx)), (mn, r.index(mn))      # (value, 0-based index)


def dry_days(r):
    return [i + 1 for i, x in enumerate(r) if x == 0]  # day numbers 1..n


def ma_naive(r, w=7):
    """Re-add the whole window for every position."""
    return [sum(r[i:i + w]) / w for i in range(len(r) - w + 1)]


def ma_running(r, w=7):
    """Running sum: add the new reading, subtract the one that leaves."""
    if len(r) < w:
        return []
    s = sum(r[:w])
    out = [s / w]
    for i in range(w, len(r)):
        s += r[i] - r[i - w]
        out.append(s / w)
    return out


def ma_deque(r, w=7):
    """Alternative concept: the window is kept in collections.deque(maxlen=w)."""
    win, s, out = deque(maxlen=w), 0.0, []
    for x in r:
        if len(win) == w:
            s -= win[0]          # value about to be pushed out
        win.append(x)
        s += x
        if len(win) == w:
            out.append(s / w)
    return out


def count_adds_naive(n, w=7):
    adds = 0
    for _ in range(max(n - w + 1, 0)):
        adds += w - 1            # adding w numbers needs w-1 additions
    return adds


def count_adds_running(n, w=7):
    if n < w:
        return 0
    adds = w - 1                 # first window
    for _ in range(w, n):
        adds += 2                # + new reading, - old reading
    return adds


def same(a, b):
    return len(a) == len(b) and all(math.isclose(x, y, abs_tol=1e-9) for x, y in zip(a, b))


if __name__ == "__main__":
    readings = make_readings(365)
    print("Readings:", len(readings), "values; first 14 =", readings[:14])

    wt = weekly_totals(readings)
    print("\nNumber of weekly blocks:", len(wt), "(52 full weeks + 1 leftover day)")
    print("First 5 weekly totals:", wt[:5])
    print("Last (partial) block total:", wt[-1], "(one day only)")
    (wk_w, tot_w), (wk_d, tot_d) = wettest_driest(readings)
    print(f"Wettest full week: week {wk_w} ({tot_w} mm); driest full week: week {wk_d} ({tot_d} mm)")
    (mx, imx), (mn, imn) = max_min_with_positions(readings)
    print(f"Max reading {mx} mm at index {imx} (day {imx + 1}); "
          f"min reading {mn} mm at index {imn} (day {imn + 1})")
    dd = dry_days(readings)
    print(f"Dry days: {len(dd)}; first 10 day numbers: {dd[:10]}")
    ma = ma_running(readings)
    print(f"7-day moving average: {len(ma)} values; first 5 = {[round(x, 2) for x in ma[:5]]}")

    print("\nSlicing demonstration on the same list:")
    print("readings[7:14]  =", readings[7:14], "-> days 8..14 (second week)")
    print("readings[-7:]   =", readings[-7:], "-> last 7 days (days 359..365)")
    print("readings[::7]   =", readings[::7][:6], "... length", len(readings[::7]),
          "-> every 7th reading (days 1, 8, 15, ...)")

    assert same(ma_naive(readings), ma_running(readings)) and same(ma_naive(readings), ma_deque(readings))
    print("\nNaive, running-sum and deque moving averages agree: True")

    cnt = {n: (count_adds_naive(n), count_adds_running(n)) for n in (365, 36500, 365000)}
    print("\nAdditions counted by simulation (formulas: naive = 6(n-6), running = 2n-8):")
    for n, (a, b) in cnt.items():
        assert a == 6 * (n - 6) and b == 2 * n - 8
        print(f"  n={n:>7}: naive={a:>9}  running={b:>7}  ratio={a / b:.2f}")
    R["adds"] = {str(n): list(v) for n, v in cnt.items()}

    print("\nEdge cases:")
    for label, data in (("empty list", []), ("3 values", [1.0, 2.0, 3.0]), ("exactly 7", [1.0] * 7)):
        print(f"  {label:<11}: weekly={weekly_totals(data)} wet/dry={wettest_driest(data)} "
              f"minmax={max_min_with_positions(data)} dry={dry_days(data)}")
        print(f"  {'':<11}  naive={ma_naive(data)} running={ma_running(data)} deque={ma_deque(data)}")

    print("\nTiming of the moving average (best of 3, seconds):")
    rows = []
    for n in (365, 36500, 365000):
        data = make_readings(n)
        t1 = best_time(lambda: ma_naive(data))
        t2 = best_time(lambda: ma_running(data))
        t3 = best_time(lambda: ma_deque(data))
        rows.append({"n": n, "naive": t1, "running": t2, "deque": t3})
        print(f"  n={n:>7}: naive={t1:.6f}  running={t2:.6f}  deque={t3:.6f}")
    R["timing"] = rows

    print("\nCost of ONE list operation (seconds, average of 20 calls):")
    ops = []
    for n in (10_000, 100_000, 1_000_000):
        mk = lambda n=n: list(range(n))
        unsorted = make_readings(n)
        res = {
            "n": n,
            "append": per_call(mk, lambda l: l.append(0)),
            "pop_end": per_call(mk, lambda l: l.pop()),
            "insert_front": per_call(mk, lambda l: l.insert(0, 0)),
            "insert_mid": per_call(mk, lambda l: l.insert(len(l) // 2, 0)),
            "pop_front": per_call(mk, lambda l: l.pop(0)),
            "sort": best_time(lambda: sorted(unsorted), 3),
        }
        ops.append(res)
        print("  n={n:>8}: append={append:.2e} pop()={pop_end:.2e} insert(0)={insert_front:.2e} "
              "insert(mid)={insert_mid:.2e} pop(0)={pop_front:.2e} sort={sort:.4f}".format(**res))
    R["ops"] = ops

    dated = list(range(1, 366))
    late_day = 200
    dated.remove(late_day)
    pos = bisect.bisect_left(dated, late_day)
    shifted = len(dated) - pos
    dated.insert(pos, late_day)
    print(f"\nLate reading for day {late_day}: bisect finds position {pos} in O(log n);"
          f" insert() then shifts {shifted} later elements, O(n).")
    assert dated == list(range(1, 366))

    by_date = {f"day{i + 1:03d}": v for i, v in enumerate(readings)}
    by_date["day200"] = 12.5
    print("Dictionary alternative: by_date['day200'] =", by_date["day200"],
          "(insert/update is O(1) average, nothing is shifted)")

    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
