"""Q7 - Design a contact-merging program from first principles."""
import json
import os
import random
import re
import time

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}
TITLES = {"dr", "mr", "mrs", "ms", "prof", "shri", "smt", "sri"}


def best_time(fn, repeat=3):
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


# ------------------------------------------------------------ normalisation
def norm_number(raw):
    """'+91 98400 12345', '098400-12345', '9840012345' -> '9840012345'. None if unusable."""
    digits = re.sub(r"\D", "", raw or "")
    if digits.startswith("00"):
        digits = digits[2:]
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    elif len(digits) == 11 and digits.startswith("0"):
        digits = digits[1:]
    return digits if len(digits) >= 6 else None


def norm_name(raw):
    """'Dr. Ravi' -> 'ravi'; 'RAVI  Kumar' -> 'ravi kumar'."""
    words = re.findall(r"[a-z]+", (raw or "").lower())
    return " ".join(w for w in words if w not in TITLES)


def norm_email(raw):
    return (raw or "").strip().lower()


def keys_of(contact):
    """Identity keys: normalised numbers; e-mail only when the contact has no number."""
    nums = {n for n in (norm_number(x) for x in contact.get("numbers", [])) if n}
    if nums:
        return nums
    return {"mail:" + e for e in (norm_email(x) for x in contact.get("emails", [])) if e}


# ------------------------------------------------------------ dictionary design (O(n))
def merge_dict(contacts):
    owner = {}        # key -> group id          (the dictionary keyed by normalised number)
    groups = {}       # group id -> {"names": set, "numbers": set, "emails": set, "keys": set}
    next_id = 0
    for c in contacts:
        keys = keys_of(c)
        hit = {owner[k] for k in keys if k in owner}
        if hit:
            gid = max(hit, key=lambda g: len(groups[g]["keys"]))     # keep the biggest group
            for other in hit - {gid}:                               # a contact bridges two groups
                g = groups.pop(other)
                for field in ("names", "numbers", "emails", "keys"):
                    groups[gid][field] |= g[field]
                for k in g["keys"]:
                    owner[k] = gid
        else:
            gid = next_id
            next_id += 1
            groups[gid] = {"names": set(), "numbers": set(), "emails": set(), "keys": set()}
        g = groups[gid]
        name = norm_name(c.get("name", ""))
        if name:
            g["names"].add(name)
        g["numbers"] |= {n for n in (norm_number(x) for x in c.get("numbers", [])) if n}
        g["emails"] |= {e for e in (norm_email(x) for x in c.get("emails", [])) if e}
        g["keys"] |= keys
        for k in keys:
            owner[k] = gid
    return finish(groups.values())


def finish(groups):
    out = []
    for g in groups:
        names = sorted(g["names"], key=lambda s: (-len(s), s))
        out.append({"name": names[0].title() if names else "(no name)",
                    "other_names": [n.title() for n in names[1:]],
                    "numbers": sorted(g["numbers"]), "emails": sorted(g["emails"])})
    return sorted(out, key=lambda r: (r["name"], r["numbers"]))


# ------------------------------------------------------------ alternative: compare every pair (O(n^2))
def merge_pairwise(contacts):
    n = len(contacts)
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    keysets = [keys_of(c) for c in contacts]
    for i in range(n):
        for j in range(i + 1, n):
            if keysets[i] & keysets[j]:
                parent[find(i)] = find(j)
    merged = {}
    for i, c in enumerate(contacts):
        g = merged.setdefault(find(i), {"names": set(), "numbers": set(), "emails": set()})
        name = norm_name(c.get("name", ""))
        if name:
            g["names"].add(name)
        g["numbers"] |= {x for x in (norm_number(v) for v in c.get("numbers", [])) if x}
        g["emails"] |= {norm_email(v) for v in c.get("emails", []) if norm_email(v)}
    return finish(merged.values())


def pretty(num):
    return f"+91 {num[:5]} {num[5:]}" if len(num) == 10 else num


# ------------------------------------------------------------ test data
FORMATS = ["+91 {a} {b}", "{a}{b}", "0{a}-{b}", "+91-{a}{b}", "91 {a}{b}", "{a} {b}"]


def make_contacts(n, seed=9):
    rnd = random.Random(seed)
    people = max(1, int(n / 1.6))
    numbers = rnd.sample(range(7_000_000_000, 9_999_999_999), people)
    first = ["ravi", "asha", "kumar", "meena", "arun", "divya", "karthik", "priya"]
    contacts = []
    for _ in range(n):
        p = rnd.randrange(people)
        num = str(numbers[p])
        raw = rnd.choice(FORMATS).format(a=num[:5], b=num[5:])
        name = rnd.choice(["Dr. ", "", "Mr ", "prof. "]) + first[p % 8] + rnd.choice(["", " kumar", f" {p % 50}"])
        c = {"name": name.upper() if rnd.random() < 0.2 else name, "numbers": [raw]}
        if rnd.random() < 0.4:
            c["emails"] = [f"{first[p % 8]}{p}@mail.com" if rnd.random() < 0.5 else f"{first[p % 8]}{p}@MAIL.com"]
        if rnd.random() < 0.05:
            c["numbers"] = []                 # missing number
        contacts.append(c)
    return contacts


def canon(result):
    return sorted((tuple(r["numbers"]), tuple(r["emails"])) for r in result)


if __name__ == "__main__":
    print("Number normalisation:")
    for raw in ("+91 98400 12345", "9840012345", "098400-12345", "91 9840012345", "+91-98400-12345", "12", None):
        print(f"  {str(raw):<18} -> {norm_number(raw)}")
    print("Name normalisation:", [norm_name(x) for x in ("Dr. Ravi", "ravi kumar", "RAVI  KUMAR", "Mrs. Asha")])

    # ---- hand-verifiable test list
    sims = [
        {"name": "Dr. Ravi", "numbers": ["+91 98400 12345"], "emails": []},                       # phone 1
        {"name": "ravi kumar", "numbers": ["9840012345", "98400 99999"], "emails": ["Ravi@Mail.com"]},   # phone 2
        {"name": "Ravi K", "numbers": ["098400-12345"], "emails": ["ravi@mail.com"]},             # SIM
        {"name": "Asha", "numbers": ["9000011111"], "emails": []},
        {"name": "Asha (office)", "numbers": ["+91 90000 11111"], "emails": ["asha@work.in"]},
        {"name": "Ravi", "numbers": ["9876543210"], "emails": []},        # DIFFERENT person, same first name
        {"name": "No Number", "numbers": [], "emails": ["nn@mail.com"]},
        {"name": "No Number Again", "numbers": [], "emails": ["NN@mail.com"]},
        {"name": "Nobody", "numbers": [], "emails": []},                  # nothing to match on
    ]
    print("\nHand-checkable input: 9 contacts -> expected 5 people:")
    print("  1 Ravi Kumar (3 records, numbers 9840012345 + 9840099999, one e-mail)")
    print("  2 Asha (2 records, 9000011111 + e-mail)")
    print("  3 Ravi (different person, 9876543210)   4 No Number* (same e-mail)   5 Nobody")
    merged = merge_dict(sims)
    print("\nProgram output:")
    for r in merged:
        print(f"  {r['name']:<16} others={r['other_names']} numbers={[pretty(n) for n in r['numbers']]} emails={r['emails']}")
    assert len(merged) == 5
    assert canon(merged) == canon(merge_pairwise(sims))
    print("Matches the hand count (5 people) and the pairwise method: True")

    bridge = [{"name": "A", "numbers": ["9111111111"]}, {"name": "B", "numbers": ["9222222222"]},
              {"name": "A+B", "numbers": ["9111111111", "9222222222"]}]
    print("\nBridging test (a contact holding both numbers joins two groups):", len(merge_dict(bridge)), "person")
    assert len(merge_dict(bridge)) == 1
    print("Empty input:", merge_dict([]), "| missing fields only:", len(merge_dict([{}, {"name": "x"}])), "records kept apart")

    print("\nTiming of the dictionary design (best of 3, seconds):")
    rows = []
    for n in (1_000, 100_000):
        data = make_contacts(n)
        t = best_time(lambda: merge_dict(data))
        res = merge_dict(data)
        rows.append({"n": n, "dict": t, "people": len(res)})
        print(f"  n={n:>7}: {t:.4f}s   -> {len(res):,} people")
    R["dict_timing"] = rows

    # requirement checks on the 100,000-contact run
    data = make_contacts(100_000)
    res = merge_dict(data)
    in_numbers = {n for c in data for n in (norm_number(x) for x in c.get("numbers", [])) if n}
    out_numbers = [n for r in res for n in r["numbers"]]
    print("\nRequirement checks on 100,000 contacts:")
    print("  R2 no number lost      :", set(out_numbers) == in_numbers)
    print("  R1 no number repeated  :", len(out_numbers) == len(set(out_numbers)),
          "(each number belongs to exactly one person)")
    R["checks"] = {"no_number_lost": set(out_numbers) == in_numbers,
                   "no_number_repeated": len(out_numbers) == len(set(out_numbers))}

    print("\nPairwise comparison vs dictionary (seconds):")
    prow = []
    for n in (500, 1_000, 2_000, 4_000):
        data = make_contacts(n)
        t_pair = best_time(lambda: merge_pairwise(data), 1)
        t_dict = best_time(lambda: merge_dict(data))
        assert canon(merge_pairwise(data)) == canon(merge_dict(data))
        prow.append({"n": n, "pairwise": t_pair, "dict": t_dict})
        print(f"  n={n:>5}: pairwise={t_pair:.4f}  dictionary={t_dict:.5f}  (same result: True)")
    R["pair_timing"] = prow
    scale = (100_000 / prow[-1]["n"]) ** 2
    est = prow[-1]["pairwise"] * scale
    print(f"\nExtrapolated pairwise time for n=100,000 = {prow[-1]['pairwise']:.3f}s x (100000/{prow[-1]['n']})^2"
          f" = {est:,.0f}s (about {est / 60:.1f} minutes); {100_000 * 99_999 // 2:,} pairs. Dictionary measured: "
          f"{rows[1]['dict']:.3f}s.")
    R["extrapolated_pairwise_100k"] = est

    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
