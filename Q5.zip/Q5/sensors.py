"""Q5 - List comprehension: Cleaning Sensor Readings (cold-storage vaccine monitor)."""
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}


def best_time(fn, repeat=3):
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


def make_readings(n, seed=5):
    """Mostly 2-8 C; some excursions; ~7% impossible sensor errors (beyond +-50 C)."""
    rnd = random.Random(seed)
    out = []
    for _ in range(n):
        u = rnd.random()
        if u < 0.07:
            out.append(round(rnd.choice([-1, 1]) * rnd.uniform(50.5, 90), 1))
        elif u < 0.17:
            out.append(round(rnd.uniform(-10, 30), 1))
        else:
            out.append(round(rnd.gauss(5, 1.2), 1))
    return out


def c_to_f(c):
    return c * 9 / 5 + 32


# ---------------- version 1: for loop with append
def clean_loop(readings):
    celsius, fahrenheit, alarms = [], [], []
    for minute, c in enumerate(readings):
        if -50 <= c <= 50:
            celsius.append(c)
            fahrenheit.append(c_to_f(c))
            if not 2 <= c <= 8:
                alarms.append(minute)
    return celsius, fahrenheit, alarms


# ---------------- version 2: list comprehensions
def clean_comp(readings):
    celsius = [c for c in readings if -50 <= c <= 50]
    fahrenheit = [c * 9 / 5 + 32 for c in readings if -50 <= c <= 50]
    alarms = [m for m, c in enumerate(readings) if -50 <= c <= 50 and not 2 <= c <= 8]
    return celsius, fahrenheit, alarms


# ---------------- version 3: map() and filter() with lambda
def clean_mapfilter(readings):
    celsius = list(filter(lambda c: -50 <= c <= 50, readings))
    fahrenheit = list(map(lambda c: c * 9 / 5 + 32, celsius))
    alarms = [m for m, c in filter(lambda p: -50 <= p[1] <= 50 and not 2 <= p[1] <= 8, enumerate(readings))]
    return celsius, fahrenheit, alarms


if __name__ == "__main__":
    sample = [4.5, 99.0, 9.1, 2.0, -70.2, 8.0, 1.9, 5.5, 50.0, -50.0]
    print("Sample readings (minute = index):", sample)
    for name, fn in (("for loop + append", clean_loop), ("list comprehension", clean_comp),
                     ("map() + filter()", clean_mapfilter)):
        c, f, a = fn(sample)
        print(f"\n{name}:\n  valid Celsius   = {c}\n  Fahrenheit      = {[round(x, 1) for x in f]}\n  alarm minutes   = {a}")
    assert clean_loop(sample) == clean_comp(sample) == clean_mapfilter(sample)
    print("\nThe three versions give identical results on the sample: True")

    print("\nGeneral form:  [expression  for item in iterable  if condition]")
    valid = [c for c in sample if -50 <= c <= 50]
    print("Dictionary comprehension {minute: C}      :", {m: c for m, c in enumerate(sample) if -50 <= c <= 50})
    print("Set comprehension {rounded valid readings}:", {round(c) for c in valid})

    print("\nEdge cases:")
    all_valid = [4.0, 5.0, 6.0, 7.0]
    all_bad = [60.0, -75.5, 99.9, -50.1]
    for label, data in (("all valid", all_valid), ("all invalid", all_bad), ("empty", [])):
        r1, r2, r3 = clean_loop(data), clean_comp(data), clean_mapfilter(data)
        assert r1 == r2 == r3
        print(f"  {label:<11}: valid={r1[0]} alarms={r1[2]}")

    print("\nTiming of the three versions (best of 3, seconds):")
    rows = []
    for n in (10_000, 100_000, 1_000_000):
        data = make_readings(n)
        t1 = best_time(lambda: clean_loop(data))
        t2 = best_time(lambda: clean_comp(data))
        t3 = best_time(lambda: clean_mapfilter(data))
        assert clean_loop(data) == clean_comp(data) == clean_mapfilter(data)
        rows.append({"n": n, "loop": t1, "comp": t2, "mapfilter": t3})
        print(f"  n={n:>9}: loop={t1:.4f}  comprehension={t2:.4f}  map/filter={t3:.4f}  (identical results: True)")
    R["timing"] = rows

    data = make_readings(1_000_000)
    lst = [c for c in data if -50 <= c <= 50]
    gen = (c for c in data if -50 <= c <= 50)
    print(f"\nMemory with sys.getsizeof: list comprehension ({len(lst):,} items) = {sys.getsizeof(lst):,} bytes;"
          f" generator expression = {sys.getsizeof(gen)} bytes")
    R["mem"] = {"list": sys.getsizeof(lst), "gen": sys.getsizeof(gen), "items": len(lst)}
    t_sum_list = best_time(lambda: sum([c for c in data if -50 <= c <= 50]))
    t_sum_gen = best_time(lambda: sum(c for c in data if -50 <= c <= 50))
    print(f"sum of valid readings: list comprehension={t_sum_list:.4f}s  generator={t_sum_gen:.4f}s")
    assert abs(sum(lst) - sum(c for c in data if -50 <= c <= 50)) < 1e-6
    R["sum"] = {"list": t_sum_list, "gen": t_sum_gen}
    g = (c for c in [1, 2, 3])
    print("A generator is used up after one pass:", list(g), "then", list(g))

    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
