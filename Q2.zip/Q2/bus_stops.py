"""Q2 - Tuples, mutability and copying: City Bus-Stop Map."""
import copy
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}


def best_time(fn, repeat=3):
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


def add_stop(passengers, stop):          # a function that changes its list argument
    passengers.append(stop)


if __name__ == "__main__":
    # ---- 1. tuples as dictionary keys + unpacking
    stops = {
        (13.0827, 80.2707): "Chennai Central",
        (13.0418, 80.2341): "T. Nagar",
        (13.0674, 80.2376): "Egmore",
        (13.0100, 80.2150): "Guindy",
    }
    print("Stops as tuple keys; unpacking in a for loop:")
    for (lat, lon), name in stops.items():
        print(f"  {name:<16} lat={lat}  lon={lon}")
    print("Lookup stops[(13.0674, 80.2376)] =", stops[(13.0674, 80.2376)])

    try:
        stops[[13.0418, 80.2341]] = "T. Nagar"
    except TypeError as e:
        print("List as key ->", type(e).__name__ + ":", e)
        R["list_key_error"] = str(e)

    # ---- 2. the grid bug and its correction (is / id)
    rows, cols = 3, 4
    bad = [[0] * cols] * rows
    good = [[0] * cols for _ in range(rows)]
    bad[0][1] = 7
    good[0][1] = 7
    print("\nbad  :", bad)
    print("good :", good)
    print("ids of rows (bad) :", [id(r) % 100000 for r in bad], "-> same object repeated")
    print("ids of rows (good):", [id(r) % 100000 for r in good], "-> three different objects")
    print("bad[0] is bad[1]  :", bad[0] is bad[1], "| good[0] is good[1]:", good[0] is good[1])
    print("[x is bad[0] for x in bad]  =", [x is bad[0] for x in bad])

    # ---- 3. aliasing, shallow copy, deep copy
    grid = [[0, 0], [0, 0]]
    alias = grid
    shallow1 = copy.copy(grid)
    shallow2 = grid[:]
    deep = copy.deepcopy(grid)
    grid[0][0] = 99            # change a ROW (inner list)
    print("\nAfter grid[0][0] = 99:")
    print("  grid     :", grid)
    print("  alias    :", alias, "(same object:", alias is grid, ")")
    print("  copy.copy:", shallow1, "(inner row shared:", shallow1[0] is grid[0], ")")
    print("  grid[:]  :", shallow2, "(inner row shared:", shallow2[0] is grid[0], ")")
    print("  deepcopy :", deep, "(inner row shared:", deep[0] is grid[0], ")")
    grid[1] = [5, 5]           # REPLACE a whole row (outer list change)
    print("After grid[1] = [5, 5] (replacing a row, outer list changed):")
    print("  grid:", grid, "| shallow copy:", shallow1, "| deep copy:", deep)

    # ---- 4. function changes the caller's list
    on_bus = ["Asha"]
    add_stop(on_bus, "Ravi")
    print("\nFunction appended to its argument; caller's list is now:", on_bus)

    # ---- 5. memory: list vs tuple of 1,000,000 values
    n = 1_000_000
    L = list(range(n))
    T = tuple(range(n))
    sl, st = sys.getsizeof(L), sys.getsizeof(T)
    print(f"\nsys.getsizeof (container only), {n:,} values: list={sl:,} bytes, tuple={st:,} bytes, "
          f"difference={sl - st:,} bytes ({(sl - st) / sl * 100:.1f}% smaller for the tuple)")
    R["mem"] = {"n": n, "list": sl, "tuple": st}
    grown = []
    for i in range(n):
        grown.append(i)              # a list that GREW by append keeps spare capacity
    sg = sys.getsizeof(grown)
    print(f"A list of the same {n:,} values built by append(): {sg:,} bytes "
          f"({sg - st:,} bytes more than the tuple, {(sg - st) / sg * 100:.1f}%)")
    R["mem"]["list_appended"] = sg
    small = {k: (sys.getsizeof(list(range(k))), sys.getsizeof(tuple(range(k)))) for k in (0, 1, 3, 10)}
    print("Small containers (list, tuple) bytes:", small)

    # ---- 6. time: create and index
    t_cl = best_time(lambda: list(range(n)))
    t_ct = best_time(lambda: tuple(range(n)))

    def index_all(seq):
        for i in range(0, n, 1):
            seq[i]
    t_il = best_time(lambda: index_all(L))
    t_it = best_time(lambda: index_all(T))
    print(f"Creation  : list={t_cl:.5f}s  tuple={t_ct:.5f}s")
    print(f"Indexing {n:,} times: list={t_il:.5f}s  tuple={t_it:.5f}s")
    R["time"] = {"create_list": t_cl, "create_tuple": t_ct, "index_list": t_il, "index_tuple": t_it}

    # ---- 7. a list stored inside a tuple
    t = ([1, 2], "route-5")
    print("\nTuple containing a list:", t)
    t[0].append(3)
    print("t[0].append(3)  -> works, tuple is now", t, "(tuple still holds the same list object)")
    try:
        t[0] = [9]
    except TypeError as e:
        print("t[0] = [9]      -> TypeError:", e)
    try:
        t[0] += [4]
    except TypeError as e:
        print("t[0] += [4]     -> TypeError:", e)
    print("...but after the failed +=, the list inside changed anyway:", t)

    # ---- 8. alternative: sparse dictionary keyed by (row, col)
    rows, cols, events = 1000, 1000, 1000
    dense = [[0] * cols for _ in range(rows)]
    sparse = {}
    import random
    rnd = random.Random(7)
    for _ in range(events):
        r, c = rnd.randrange(rows), rnd.randrange(cols)
        dense[r][c] += 1
        sparse[(r, c)] = sparse.get((r, c), 0) + 1
    dense_bytes = sys.getsizeof(dense) + sum(sys.getsizeof(row) for row in dense)
    sparse_bytes = sys.getsizeof(sparse)
    print(f"\n{rows}x{cols} zones, {events} boardings: list-of-lists container memory={dense_bytes:,} bytes "
          f"({rows * cols:,} cells); dict container memory={sparse_bytes:,} bytes ({len(sparse):,} entries)")
    assert all(dense[r][c] == v for (r, c), v in sparse.items())
    R["grid_mem"] = {"dense": dense_bytes, "sparse": sparse_bytes, "cells": rows * cols, "entries": len(sparse)}
    a = best_time(lambda: [dense[r][c] for (r, c) in list(sparse)[:1000]])
    b = best_time(lambda: [sparse.get(k, 0) for k in list(sparse)[:1000]])
    print(f"1000 lookups: list-of-lists={a:.6f}s  dict={b:.6f}s (both O(1) average)")

    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
