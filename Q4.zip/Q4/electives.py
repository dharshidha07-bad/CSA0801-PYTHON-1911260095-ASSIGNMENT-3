"""Q4 - Sets: Elective Registration Clash Detection."""
import json
import os
import random
import time

HERE = os.path.dirname(os.path.abspath(__file__))
R = {}


def best_time(fn, repeat=3):
    best = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn()
        best = min(best, time.perf_counter() - t0)
    return best


def report(a, b, everyone):
    return {"clash (A & B)": sorted(a & b),
            "only A (A - B)": sorted(a - b),
            "only B (B - A)": sorted(b - a),
            "exactly one (A ^ B)": sorted(a ^ b),
            "either (A | B)": sorted(a | b),
            "neither (U - (A | B))": sorted(everyone - (a | b))}


def common_nested(a_list, b_list):
    out = []
    for x in a_list:
        for y in b_list:
            if x == y:
                out.append(x)
                break
    return out


def common_sorted_walk(a_list, b_list):
    a, b = sorted(a_list), sorted(b_list)
    i = j = 0
    out = []
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            out.append(a[i]); i += 1; j += 1
        elif a[i] < b[j]:
            i += 1
        else:
            j += 1
    return out


if __name__ == "__main__":
    # raw registrations, with duplicate entries (a student clicked twice)
    ai_raw = ["192311001", "192311004", "192311004", "192311007", "192311009", "192311001"]
    iot_raw = ["192311002", "192311004", "192311009", "192311010", "192311009"]
    print("AI raw list has", len(ai_raw), "entries ->", len(set(ai_raw)), "after set():", sorted(set(ai_raw)))
    ai, iot = set(ai_raw), set(iot_raw)
    everyone = {f"1923110{i:02d}" for i in range(1, 11)}
    print("\nSorted reports:")
    for k, v in report(ai, iot, everyone).items():
        print(f"  {k:<22}: {v}")

    # hand verification of a tiny case
    A, B, U = {1, 2, 3}, {3, 4}, {1, 2, 3, 4, 5}
    hand = {"A&B": {3}, "A-B": {1, 2}, "B-A": {4}, "A^B": {1, 2, 4}, "A|B": {1, 2, 3, 4}, "U-(A|B)": {5}}
    comp = {"A&B": A & B, "A-B": A - B, "B-A": B - A, "A^B": A ^ B, "A|B": A | B, "U-(A|B)": U - (A | B)}
    print("\nHand-worked case A={1,2,3}, B={3,4}, U={1..5}:")
    for k in hand:
        print(f"  {k:<8} hand={sorted(hand[k])}  program={sorted(comp[k])}  match={hand[k] == comp[k]}")

    print("\nEdge cases:")
    print("  both electives empty   :", report(set(), set(), everyone)["clash (A & B)"],
          "| neither =", len(report(set(), set(), everyone)["neither (U - (A | B))"]), "students")
    print("  one elective empty     : clash =", sorted(ai & set()), "| exactly one =", sorted(ai ^ set()))
    same = report(ai, set(ai), everyone)
    print("  identical electives    : clash =", same["clash (A & B)"], "| exactly one =", same["exactly one (A ^ B)"])
    try:
        {[1, 2]}
    except TypeError as e:
        print("  set of a list          : TypeError:", e)
    print("  set of a tuple         :", {(1, 2), (1, 2), (3, 4)})

    print("\nMembership test, worst case (the LAST element), seconds per lookup:")
    rows = []
    for n in (10_000, 100_000, 1_000_000):
        regs = [f"19{i:07d}" for i in range(n)]
        s = set(regs)
        target = regs[-1]
        reps = 20 if n <= 100_000 else 5
        t_list = best_time(lambda: [target in regs for _ in range(reps)]) / reps
        t_set = best_time(lambda: [target in s for _ in range(reps)]) / reps
        rows.append({"n": n, "list": t_list, "set": t_set})
        print(f"  n={n:>9}: list={t_list:.3e}  set={t_set:.3e}  ratio={t_list / t_set:,.0f}x")
    R["membership"] = rows

    print("\nFinding common students (two lists of n numbers, half in common), seconds:")
    rows = []
    for n in (500, 1000, 2000, 4000):
        a_list = [f"19{i:07d}" for i in range(n)]
        b_list = [f"19{i:07d}" for i in range(n // 2, n // 2 + n)]
        t_nested = best_time(lambda: common_nested(a_list, b_list), 1)
        t_sorted = best_time(lambda: common_sorted_walk(a_list, b_list))
        t_set = best_time(lambda: set(a_list) & set(b_list))
        assert sorted(common_nested(a_list, b_list)) == common_sorted_walk(a_list, b_list) == sorted(set(a_list) & set(b_list))
        rows.append({"n": n, "nested": t_nested, "sorted": t_sorted, "set": t_set})
        print(f"  n={n:>5}: nested loops={t_nested:.5f}  sort+walk={t_sorted:.5f}  set &={t_set:.6f}")
    R["common"] = rows

    with open(os.path.join(HERE, "results.json"), "w") as f:
        json.dump(R, f, indent=1)
